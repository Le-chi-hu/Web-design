// 創建星空背景容器
const starryBackground = document.createElement('div');
starryBackground.classList.add('starry-background');//css連接
document.body.appendChild(starryBackground);// 將星空背景容器添加到 `body` 中，成為頁面的一部分。


// 動態生成星星
const starCount = 100; // 星星數量
for (let i = 0; i < starCount; i++) {
    const star = document.createElement('div');
    star.classList.add('star');//css連接

    // 隨機位置
    star.style.top = `${Math.random() * 100}vh`;
    star.style.left = `${Math.random() * 100}vw`;

    // 隨機大小
    const size = Math.random() * 3 + 1; 
    star.style.width = `${size}px`;
    star.style.height = `${size}px`;

    // 隨機閃爍延遲
    star.style.animationDelay = `${Math.random() * 2}s`;

    // 添加星星到背景容器
    starryBackground.appendChild(star);
}
