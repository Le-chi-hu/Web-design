from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')  
def home():
    return render_template('home.html')

@app.route('/career')  
def career():
    return render_template('career.html')

@app.route('/background')  
def background():
    return render_template('background.html')

@app.route('/GD')  
def GD():
    return render_template('GD.html')

if __name__ == '__main__':
    app.run(debug=True)