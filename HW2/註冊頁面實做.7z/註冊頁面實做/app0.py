from flask import Flask, render_template, request

app = Flask(__name__, template_folder='templates')



@app.route('/', methods=['POST', 'GET'])
def index():
    if request.method == 'POST':

        name = request.form['name']
        gender = request.form['gender']
        unit = request.form['unit']
        email = request.form['email']
        password = request.form['password']
        phone = request.form['phone']
        
      
        return render_template('reg.html', user=name, gender=gender, unit=unit, email=email, password=password, phone=phone)
    
  
    return render_template('reg.html', user="", gender="", unit="", email="", password="", phone="")

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080, debug=True)
