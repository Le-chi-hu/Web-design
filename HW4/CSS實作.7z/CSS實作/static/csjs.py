import json

# 建立字典
person_dict = {
    "me": {
        "age": 20,
        "gender": "male",
        "hobbies": "reading"
    },
    "Mary": {
        "age": 21,
        "gender": "female",
        "hobbies": "dancing", 
    },
    "John": {
        "age": 22,
        "gender": "male",
        "hobbies": "gaming"
       
    }
}

with open('person.json', 'w') as json_file:
    json.dump(person_dict, json_file)

with open('person.json', 'r') as f:
    data = json.load(f)

print(json.dumps(person_dict, indent=4, separators=(',', '=')))